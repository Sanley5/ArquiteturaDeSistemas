package br.usjt.usjt_ccp3_consumo_img_init;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsjtCcp3ConsumoImgApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsjtCcp3ConsumoImgApplication.class, args);
	}
}
