package br.usjt.usjt_ccp3_consumo_img_init;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsjtCcp3ConsumoImgApplicationTests {

	@Test
	void contextLoads() {
	}

}
