package exercicio_1_1;

public class ProdutoScreen implements Produto {

	@Override
	public void imprimir() {
		
		System.out.println("Hello, World Tela");

	}

}
