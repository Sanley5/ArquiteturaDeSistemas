package exercicio_1_1;

public class ProdutoFile implements Produto {

	@Override
	public void imprimir() {
		
		System.out.println("Hello, World File");

	}

}
