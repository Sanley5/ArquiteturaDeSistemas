package exercicio_1_1;

public interface Fabrica {
	
	Produto getProduto(String imprimirTipo); 

}
