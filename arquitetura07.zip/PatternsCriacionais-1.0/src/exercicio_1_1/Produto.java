package exercicio_1_1;

public interface Produto {

	public void imprimir();
}
