package exercicio_2_3;



public class FerramentaConsole extends Ferramenta {

	public void registrarLog(String mensagem) {
		System.out.println(mensagem);
	}
}
