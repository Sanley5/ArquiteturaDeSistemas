package exercicio_2_3;

public abstract class Ferramenta {

	public abstract void registrarLog(String mensagem);
}

