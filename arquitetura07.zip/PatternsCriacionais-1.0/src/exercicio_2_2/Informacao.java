package exercicio_2_2;

public interface Informacao {
	
	public String informacao();

}
