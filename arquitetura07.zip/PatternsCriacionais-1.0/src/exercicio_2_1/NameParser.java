package exercicio_2_1;

public interface NameParser {
	
	public Nome parse(String nome);

}
