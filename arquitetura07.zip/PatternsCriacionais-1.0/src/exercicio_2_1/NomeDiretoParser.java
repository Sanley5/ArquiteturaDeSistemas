package exercicio_2_1;

public class NomeDiretoParser extends NameParserCreator {

	@Override
	protected NameParser getParser() {
		// TODO Auto-generated method stub
		return new NomeDireto();
	}

}
