package exercicio_1_2;

public class PizzaPresunto implements Produto {

	@Override
	public String fazer() {
		
		return "Pizza de Presunto: queijo, presunto e tomate";
	}

}
