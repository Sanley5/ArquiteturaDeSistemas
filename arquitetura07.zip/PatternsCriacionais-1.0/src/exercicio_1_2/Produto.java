package exercicio_1_2;

public interface Produto {
	
	public String fazer();

}
