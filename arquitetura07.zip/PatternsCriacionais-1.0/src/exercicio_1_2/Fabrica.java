package exercicio_1_2;

public interface Fabrica {
	
	public Produto getProduto(int tipo);

}
