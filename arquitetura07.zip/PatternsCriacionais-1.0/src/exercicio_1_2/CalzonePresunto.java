package exercicio_1_2;

public class CalzonePresunto implements Produto {

	@Override
	public String fazer() {
		
		return "Calzone de Presunto: queijo, presunto e tomate";
	}

}
