package exercicio_1_2;

public class CalzoneCalabresa implements Produto {

	@Override
	public String fazer() {
		
		return "Calzone de Calabresa: queijo, calabresa e tomate";
	}

}
