package exercicio_1_2;

public class PizzaCalabresa implements Produto{

	@Override
	public String fazer() {
		
		return "Pizza de Calabresa: queijo, calabresa e tomate";
	}
	
	
	

}
